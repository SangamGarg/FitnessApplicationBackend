package com.fitnessapp.appAuth.model.dtos;

import com.fitnessapp.appAuth.model.enums.ActivityLevel;
import com.fitnessapp.appAuth.model.enums.FitnessGoal;
import com.fitnessapp.appAuth.model.enums.Gender;
import jakarta.validation.constraints.*;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDetailsDto {

    @NotBlank(message = "Name cannot be empty")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    private String email;


    private List<@NotBlank String> firebaseCloudMessagingToken;

    @NotNull(message = "Gender cannot be null")
    private Gender gender;

    @NotNull(message = "Age cannot be null")
    @Min(value = 13, message = "Minimum age must be 13")
    @Max(value = 120, message = "Age cannot exceed 120")
    private Integer age;

    @Pattern(regexp = "^(http|https)://.*$", message = "Profile image URL must be a valid URL")
    private String profileImageUrl;

    @NotNull(message = "Height cannot be null")
    @DecimalMin("50.0")
    @DecimalMax("250.0")
    private BigDecimal heightCm;

    @NotNull(message = "Weight cannot be null")
    @DecimalMin("10.0")
    @DecimalMax("500.0")
    private BigDecimal weightKg;

    @NotNull(message = "Activity level cannot be null")
    private ActivityLevel activityLevel;

    @NotNull(message = "Goal cannot be null")
    private FitnessGoal goal;

//    @Positive(message = "Hip measurement must be positive")
//    @Max(value = 300, message = "Hip must be at most 300cm")
//    private Float hipCm;
//
//    @Positive(message = "Neck measurement must be positive")
//    @Max(value = 100, message = "Neck must be at most 100cm")
//    private Float neckCm;
//
//    @Positive(message = "Waist measurement must be positive")
//    @Max(value = 150, message = "Waist must be at most 150 cm")
//    private Float waistCm;
//
//    private BigDecimal bmi;
//    private BigDecimal dailyCalories;
//    private BigDecimal idealWeight;
//    private BigDecimal bodyFat;
}
