package com.fitnessapp.appAuth.utils;

import com.fitnessapp.appAuth.model.dtos.UserDetailsDto;
import com.fitnessapp.appAuth.model.dtos.requestDto.UserPatchRequestDto;
import com.fitnessapp.appAuth.model.entity.UserDetailsEntity;
import com.fitnessapp.calculator.model.dtos.requestDto.BodyFatRequestDto;
import com.fitnessapp.calculator.model.dtos.requestDto.DailyCaloriesRequestDto;
import com.fitnessapp.calculator.model.dtos.responseDto.BmiCalculateResponseDto;
import com.fitnessapp.calculator.model.dtos.responseDto.BodyFatResponseDto;
import com.fitnessapp.calculator.model.dtos.responseDto.DailyCaloriesResponseDto;
import com.fitnessapp.calculator.model.dtos.responseDto.IdealWeightResponseDto;
import com.fitnessapp.calculator.service.CalculatorService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Map;

public final class AppAuthUtils {

    public static String getUserIdFromTokenInHeader() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null ? authentication.getName() : null; // This is the Firebase UID from the token
    }

    public static UserDetailsDto userDetailsEntityToUserDetailsDto(UserDetailsEntity user) {
        return UserDetailsDto.builder()
                .name(user.getName())
                .firebaseCloudMessagingToken(user.getFirebaseCloudMessagingToken())
                .email(user.getEmail())
                .gender(user.getGender())
                .age(user.getAge())
                .profileImageUrl(user.getProfileImageUrl())
                .heightCm(user.getHeightCm())
                .weightKg(user.getWeightKg())
                .activityLevel(user.getActivityLevel())
                .goal(user.getGoal())
//                .hipCm(user.getHipCm())
//                .neckCm(user.getNeckCm())
//                .waistCm(user.getWaistCm())
                .build();
    }

    public static UserDetailsEntity patchLogic(UserPatchRequestDto userDetailsDto, UserDetailsEntity existingUserDetails) {


        if (userDetailsDto.getName() != null) existingUserDetails.setName(userDetailsDto.getName());
        if (userDetailsDto.getFirebaseCloudMessagingToken() != null && !userDetailsDto.getFirebaseCloudMessagingToken().isEmpty())
            existingUserDetails.setFirebaseCloudMessagingToken(userDetailsDto.getFirebaseCloudMessagingToken());
        if (userDetailsDto.getGender() != null) existingUserDetails.setGender(userDetailsDto.getGender());
        if (userDetailsDto.getAge() != null) existingUserDetails.setAge(userDetailsDto.getAge());
        if (userDetailsDto.getProfileImageUrl() != null)
            existingUserDetails.setProfileImageUrl(userDetailsDto.getProfileImageUrl());
        existingUserDetails.setHeightCm(userDetailsDto.getHeightCm());
        existingUserDetails.setWeightKg(userDetailsDto.getWeightKg());
        if (userDetailsDto.getActivityLevel() != null)
            existingUserDetails.setActivityLevel(userDetailsDto.getActivityLevel());
        if (userDetailsDto.getGoal() != null) existingUserDetails.setGoal(userDetailsDto.getGoal());
//        if (userDetailsDto.getHipCm() != null && userDetailsDto.getHipCm() > 0)
//            existingUserDetails.setHipCm(userDetailsDto.getHipCm());
//        if (userDetailsDto.getNeckCm() != null && userDetailsDto.getNeckCm() > 0)
//            existingUserDetails.setNeckCm(userDetailsDto.getNeckCm());
//        if (userDetailsDto.getWaistCm() != null && userDetailsDto.getWaistCm() > 0)
//            existingUserDetails.setWaistCm(userDetailsDto.getWaistCm());

        return existingUserDetails;
    }
}