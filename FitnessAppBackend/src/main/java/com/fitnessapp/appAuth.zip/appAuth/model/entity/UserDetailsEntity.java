package com.fitnessapp.appAuth.model.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fitnessapp.appAuth.model.enums.ActivityLevel;
import com.fitnessapp.appAuth.model.enums.FitnessGoal;
import com.fitnessapp.appAuth.model.enums.Gender;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "app_user_details")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDetailsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_details_id")
    private Long id;

    // A simple list of strings stored in its own table "fcm_tokens".
    // NOT unique: the same phone token may briefly exist on two accounts; the service removes it from
    // other users whenever it is registered (see UserDetailsRepo.removeTokensFromOtherUsers).
    @ElementCollection(fetch = FetchType.LAZY)
    @Column(nullable = false)
    @CollectionTable(name = "fcm_tokens", joinColumns = @JoinColumn(name = "user_details_id"))
    @Builder.Default
    private List<String> firebaseCloudMessagingToken = new ArrayList<>();


    @Column(nullable = false, unique = true, length = 320)
    private String email;

    @Column(length = 100)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(length = 30)
    private Gender gender;
    private Integer age;
    private String profileImageUrl;
    @Column(name = "height_cm", precision = 5, scale = 2)
    private BigDecimal heightCm;

    @Column(name = "weight_kg", precision = 6, scale = 2)
    private BigDecimal weightKg;
    @Enumerated(EnumType.STRING)
    private ActivityLevel activityLevel;

    @Enumerated(EnumType.STRING)
    private FitnessGoal goal;
    //    private Float hipCm;
//    private Float neckCm;
//    private Float waistCm;
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Instant updatedAt;
    // Mandatory one-to-one link to UserEntity (foreign key column "user_id").
    // Excluded from toString/equals/hashCode to avoid infinite recursion with UserEntity.
    @OneToOne(optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private UserEntity user;
}