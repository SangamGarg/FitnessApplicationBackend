package com.fitnessapp.appAuth.model.dtos.requestDto;

import com.fitnessapp.appAuth.model.enums.ActivityLevel;
import com.fitnessapp.appAuth.model.enums.FitnessGoal;
import com.fitnessapp.appAuth.model.enums.Gender;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserPatchRequestDto {


    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    private List<String> firebaseCloudMessagingToken;


    //^	Start of the string
    //(?i)	Case-insensitive flag (so "Male", "MALE", "male" are all accepted)
    //$	End of the string
    @NotNull(message = "Gender cannot be null")
    private Gender gender;


    @Min(value = 13, message = "Age must be at least 1")
    @Max(value = 120, message = "Age must be realistic (<=120)")
    private Integer age;

    @Pattern(regexp = "^(http|https)://.*$", message = "Profile image URL must be a valid URL")
    private String profileImageUrl;

    @NotNull(message = "Height cannot be null")
    @DecimalMin("50.0")
    @DecimalMax("250.0")
    private BigDecimal heightCm;

    @NotNull(message = "Weight cannot be null")
    @DecimalMin("10.0")
    @DecimalMax("500.0")
    private BigDecimal weightKg;

    @NotNull(message = "Activity level cannot be null")
    private ActivityLevel activityLevel;

    @NotNull(message = "Goal cannot be null")
    private FitnessGoal goal;

//
//    @PositiveOrZero(message = "Hip measurement must be positive")
//    @Max(value = 300, message = "Hip must be at most 300cm")
//    private Float hipCm;
//
//    @PositiveOrZero(message = "Neck measurement must be positive")
//    @Max(value = 100, message = "Neck must be at most 100cm")
//    private Float neckCm;
//
//    @PositiveOrZero(message = "Waist measurement must be positive")
//    @Max(value = 150, message = "Waist must be at most 150 cm")
//    private Float waistCm;
}
